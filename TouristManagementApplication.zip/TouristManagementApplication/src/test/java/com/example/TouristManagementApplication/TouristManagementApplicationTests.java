package com.example.TouristManagementApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TouristManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
