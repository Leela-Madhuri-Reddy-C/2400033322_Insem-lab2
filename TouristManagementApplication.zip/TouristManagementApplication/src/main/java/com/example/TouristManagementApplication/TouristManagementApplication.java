package com.example.TouristManagementApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TouristManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(TouristManagementApplication.class, args);
	}

}
